/**
 *  @brief Tworzenie zadan w systemie FreeRTOS
 *
 *
 *
 */

#ifndef INC_DRIVERLED_H
#define INC_DRIVERLED_H

#include <stdint.h>
#include "main.h"

#define LED1 LED2_Pin
#define LED2 LED3_Pin

void driverLED_init(void);
void driverLED_toggle(uint16_t led);

#endif//INC_DRIVERLED_H
