#include "driverKEY.h"


void driverKEY_init(void)
{
	#warning Przyciski zainicjowane przez bilioteke HAL
}

uint8_t driverKEY_read(void)
{
	uint8_t key_state = 0;

	if (HAL_GPIO_ReadPin(JOY_D_GPIO_Port, JOY_D_Pin) == GPIO_PIN_RESET)
		key_state |= JOY_D;
	if (HAL_GPIO_ReadPin(JOY_U_GPIO_Port, JOY_U_Pin) == GPIO_PIN_RESET)
		key_state |= JOY_U;
	if (HAL_GPIO_ReadPin(JOY_L_GPIO_Port, JOY_L_Pin) == GPIO_PIN_RESET)
		key_state |= JOY_L;
	if (HAL_GPIO_ReadPin(JOY_R_GPIO_Port, JOY_R_Pin) == GPIO_PIN_RESET)
		key_state |= JOY_R;
	if (HAL_GPIO_ReadPin(JOY_OK_GPIO_Port, JOY_OK_Pin) == GPIO_PIN_RESET)
		key_state |= JOY_OK;

	if (HAL_GPIO_ReadPin(SW3_GPIO_Port, SW3_Pin) == GPIO_PIN_RESET)
		key_state |= SW3;
	if (HAL_GPIO_ReadPin(SW4_GPIO_Port, SW4_Pin) == GPIO_PIN_RESET)
		key_state |= SW4;

	return key_state;
}
